package com.zzh.service.inter;

import com.zzh.model.PersonModel;

public interface SpringDemoService {

	PersonModel getPerson();
}
